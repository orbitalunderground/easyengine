Please attach the output of following command when open a new support request.

- [ ] lsb_release -a
- [ ] ee -v
- [ ] ee info
- [ ] wp --allow-root --info
